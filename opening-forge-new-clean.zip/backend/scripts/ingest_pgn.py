def main():
    print("Opening Forge PGN ingestion placeholder.")
    print("Use a hosted backend for the full Lichess database.")

if __name__ == "__main__":
    main()
