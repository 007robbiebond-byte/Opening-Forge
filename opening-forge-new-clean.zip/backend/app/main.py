from fastapi import FastAPI, Query
from pydantic import BaseModel

app = FastAPI(title="Opening Forge API")

@app.get("/health")
def health():
    return {"ok": True, "service": "opening-forge"}

@app.get("/position")
def position(fen: str = Query(...)):
    return {"fen": fen, "moves": [], "message": "Database index not loaded yet."}

class TrainingAnswer(BaseModel):
    fen: str
    answer: str

@app.post("/training/answer")
def training_answer(item: TrainingAnswer):
    return {"ok": True, "fen": item.fen, "answer": item.answer}

@app.get("/repertoire/seed")
def repertoire_seed():
    return {"opening": "Starting Position", "moves": []}
