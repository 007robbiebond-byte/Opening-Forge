# Opening Forge

Native Android chess opening trainer foundation.

## Layout

- `android/` — Kotlin Android app
- `backend/` — FastAPI backend foundation
- `.github/workflows/` — GitHub Actions APK build

## Build

1. Upload this repository to GitHub.
2. Open Actions.
3. Select Build Android APK.
4. Run the workflow.
5. Download `opening-forge-debug-apk`.

The full Lichess database will be hosted separately rather than bundled into the phone APK.

This is the clean buildable foundation; Stockfish, legal move handling, database indexing, Lichess import/OAuth, repertoire expansion, and spaced repetition are subsequent iterations.
