package com.openingforge.app

import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }

        root.addView(TextView(this).apply {
            text = "Opening Forge"
            textSize = 28f
        })
        root.addView(TextView(this).apply {
            text = "Chess opening trainer\n\nTRAIN  •  REPERTOIRE  •  EXPLORER  •  ANALYTICS"
            textSize = 18f
            setPadding(0, 24, 0, 0)
        })

        setContentView(root)
    }
}
